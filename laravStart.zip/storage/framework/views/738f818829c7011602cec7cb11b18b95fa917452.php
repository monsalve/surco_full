
    <?php echo $__env->make('header2', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    

    <div class="site-section ftco-subscribe-1 site-blocks-cover pb-4" style="background-image: url('img/bg_1.jpg')">
        <div class="container">
          <div class="row align-items-end">
            <div class="col-lg-7">
              <h2 class="mb-0">Registro</h2>
              <p>Solicitud registro.</p>
            </div>
          </div>
        </div>
      </div> 
    

    <div class="custom-breadcrumns border-bottom">
      <div class="container">
        <a href="/">Inicio</a>
        <span class="mx-3 icon-keyboard_arrow_right"></span>
        <span class="current">Solicitud</span>
      </div>
    </div>

    <div class="site-section">
        <div class="container">
            <div class="row">
              <div class="jumbotron">
                <h1 class="display-4">Hemos recibido tu solicitud!!!</h1>
                <p class="lead">En breve nos comunicaremos contigo</p>
                <hr class="my-4">
                <p>Te invitamos a que continues conociendo nuestra oferta académica.</p>
                <a class="btn btn-primary btn-lg" href="/" role="button">Volver al Inicio </a>
              </div>
                
            </div>
        </div>
    </div>

      
    <?php echo $__env->make('contactenos2', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    <?php echo $__env->make('footer2', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
     